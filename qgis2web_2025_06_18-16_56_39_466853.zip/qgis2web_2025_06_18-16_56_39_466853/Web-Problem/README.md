# Web-Problem

zanzibar social service distribution versus population

made by me!(Aisha)

## Data

came from simple maps of population versus services.org

## 🌍 Live Map
[Click here to view the interactive QGIS map](https://moonaish025.github.io/Web-Problem/)
